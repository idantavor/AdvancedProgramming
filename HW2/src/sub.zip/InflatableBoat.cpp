#include "InflatableBoat.h"

char InflatableBoat::symbolAPlayer = 'B';
char InflatableBoat::symbolBPlayer = 'b';
int InflatableBoat::length = 1;
int InflatableBoat::score = 2;